import datetime
from django.db import models
from django.utils.timezone import now


# Create your models here.
class BusinessInformation(models.Model):
    user = models.CharField(max_length=50)
    Client_Name  = models.CharField(max_length=50)
    Domain = models.CharField(max_length=50)
    Work_Location = models.CharField(max_length=50)
    Offered_CTC = models.IntegerField()
    Hike_perce_given = models.FloatField()
    Per_Month_Client_Billing = models.IntegerField()
    Annual_Client_Billing = models.FloatField()
    Gross_Margin = models.IntegerField()
    Gross_Margin_perce = models.FloatField()
    Project_start_date=models.DateField(auto_now=False)
    Project_end_date=models.DateField(auto_now=False)
    salary_commense_date=models.DateField(auto_now=False)
    Initial_Reporting=models.CharField(max_length=30)
    source=models.CharField(max_length=30)
    delivery_memeber=models.CharField(max_length=30)
    business_unit=models.CharField(max_length=30)
    date_of_request=models.DateField(auto_now=False)
    Relocation_Amount = models.BooleanField()
    Travel_Allowance = models.BooleanField()
    Project_Allowance = models.BooleanField()




class CandidateInformationBench(models.Model):
    Candidate_Name=models.CharField(blank=False,default=None,max_length=30)
    Gender=models.CharField(blank=False,default=None,max_length=10)
    Email_ID=models.EmailField(blank=False,default=None,max_length=254)
    Contact_Number=models.IntegerField(blank=False,default=None)
    Experience=models.CharField(blank=False,default=None,max_length=30)
    Total_Experience=models.CharField(blank=False,default=None,max_length=30)
    Relevant_Experience=models.CharField(blank=False,default=None,max_length=30)
    Skill_Set=models.CharField(blank=False,default=None,max_length=30)
    Current_CTC=models.FloatField(blank=False,default=None)
    Notice_Period=models.CharField(blank=False,default=None,max_length=30)

class CandidateInformationInternal(models.Model):
    Candidate_Name=models.CharField(blank=False,default=None,max_length=30)
    Gender=models.CharField(blank=False,default=None,max_length=10)
    Email_ID=models.EmailField(blank=False,default=None,max_length=254)
    Contact_Number=models.IntegerField(blank=False,default=None)
    Experience=models.CharField(blank=False,default=None,max_length=30)
    Total_Experience=models.CharField(blank=False,default=None,max_length=30)
    Relevant_Experience=models.CharField(blank=False,default=None,max_length=30)
    Skill_Set=models.CharField(blank=False,default=None,max_length=30)
    Current_CTC=models.FloatField(blank=False,default=None)
    Notice_Period=models.CharField(blank=False,default=None,max_length=30)


class CandidateInformationExternal(models.Model):
    Candidate_Name=models.CharField(blank=False,default=None,max_length=30)
    Gender=models.CharField(blank=False,default=None,max_length=10)
    Email_ID=models.EmailField(blank=False,default=None,max_length=254)
    Contact_Number=models.IntegerField(blank=False,default=None)
    Experience=models.CharField(blank=False,default=None,max_length=30)
    Total_Experience=models.CharField(blank=False,default=None,max_length=30)
    Relevant_Experience=models.CharField(blank=False,default=None,max_length=30)
    Skill_Set=models.CharField(blank=False,default=None,max_length=30)
    Current_CTC=models.FloatField(blank=False,default=None)
    Notice_Period=models.CharField(blank=False,default=None,max_length=30)
    Client_Name  = models.CharField(max_length=50)
    Domain = models.CharField(max_length=50)
    Work_Location = models.CharField(max_length=50)
    Offered_CTC = models.IntegerField()
    Hike_perce_given = models.FloatField()
    Per_Month_Client_Billing = models.IntegerField()
    Annual_Client_Billing = models.FloatField()
    Gross_Margin = models.IntegerField()
    Gross_Margin_perce = models.FloatField()
    Project_start_date=models.DateField(auto_now=False)
    Project_end_date=models.DateField(auto_now=False)
    salary_commense_date=models.DateField(auto_now=False)
    Initial_Reporting=models.CharField(max_length=30)
    source=models.CharField(max_length=30)
    delivery_memeber=models.CharField(max_length=30)
    business_unit=models.CharField(max_length=30)
    date_of_request=models.DateField(auto_now=False)
    Relocation_Amount = models.BooleanField()
    Travel_Allowance = models.BooleanField()
    Project_Allowance = models.BooleanField()
    def __str__(self):
        return self.Candidate_Name
