from django.shortcuts import render
from . import forms
from hrapp.forms import BenchForm,InternalForm,ExternalForm
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.contrib.auth.decorators import login_required





def index(request):
    return render(request,'hrapp/index.html')

@login_required
def special(request):
    return HttpResponse("You are logged in !")
@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('index'))

def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user:
            if user.is_active:
                login(request,user)
                return HttpResponseRedirect(reverse('index'))
            else:
                return HttpResponse("Your account was inactive.")
        else:
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username,password))
            return HttpResponse("Invalid login details given")
    else:
        return render(request, 'hrapp/login.html', {})





def index1(request):
    return render(request,'hrapp/index1.html')

@login_required
def special1(request):
    return HttpResponse("You are logged in !")
@login_required
def Delivery_Team_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('index1'))


def Delivery_Team_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user1 = authenticate(username=username, password=password)
        if user1:
            if user1.is_active:
                login(request,user1)
                return HttpResponseRedirect(reverse('index1'))
            else:
                return HttpResponse("Your account was inactive.")
        else:
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username,password))
            return HttpResponse("Invalid login details given")
    else:
        return render(request, 'hrapp/login.html', {})


def candidate_bench(request):
    registered = False
    if request.method=='POST':
        user_form=BenchForm(request.POST)
        if user_form.is_valid():
            user=user_form.save()

            registered=True
    else:
        user_form=BenchForm()
    return render(request,'hrapp/bench.html',{'user_form':user_form,'registered':registered})

def candidate_Internal(request):
    registered = False
    if request.method=='POST':
        user_form=InternalForm(request.POST)
        if user_form.is_valid():
            user_form.save()
            registered = True
    else:
        user_form=InternalForm()
    return render(request,'hrapp/Internal.html',{'user_form':user_form,'registered':registered})

def candidate_External(request):
    registered = False
    if request.method=='POST':
        user_form=ExternalForm(request.POST)
        if user_form.is_valid():
            user=user_form.save()
        registered = True
    else:
        user_form=ExternalForm()
    return render(request,'hrapp/External.html',{'user_form':user_form,'registered':registered})
