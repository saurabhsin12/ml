from django.contrib import admin
from hrapp.models import BusinessInformation,CandidateInformationBench,CandidateInformationInternal,CandidateInformationExternal

# Register your models here.
class BussinessAdmin(admin.ModelAdmin):
    list_display = ['user','Client_Name','Domain','Work_Location','Offered_CTC','Hike_perce_given','Per_Month_Client_Billing','Annual_Client_Billing','Gross_Margin','Gross_Margin_perce','Project_start_date','Project_end_date','salary_commense_date','Initial_Reporting','source','delivery_memeber','business_unit','date_of_request','Relocation_Amount','Travel_Allowance','Project_Allowance']
admin.site.register(BusinessInformation,BussinessAdmin)
