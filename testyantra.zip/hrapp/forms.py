from django import forms
from hrapp.models import CandidateInformationBench,CandidateInformationInternal,CandidateInformationExternal



class BenchForm(forms.ModelForm):
    class Meta:
        model = CandidateInformationBench
        fields = '__all__'

class InternalForm(forms.ModelForm):
    class Meta:
        model = CandidateInformationInternal
        fields = '__all__'

class ExternalForm(forms.ModelForm):
    class Meta:
        model = CandidateInformationExternal
        fields = '__all__'
