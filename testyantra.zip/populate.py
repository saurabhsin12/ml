import os
os.environ.setdefault('DJANGO_SETTING_MODULE','testyantra.settings')

import django
django.setup()

import random
from testyantra.models import BusinessInformation
from faker import Faker

fakegen = Faker()
topics = ['Search']

def add_topic():
    t = BusinessInformation.objects.get_or_create(Client_Name=random.choice(topics))[0]
    t.save()
    return t

def populate(N=5):
    for entry in range(N):
        top = add_topic()

        fake_name = fakegen.name()


        webpg = BusinessInformation.objects.get_or_create(name=fake_name)[0]

if __name__ == '__main__':
    print('populating script')
    populate(20)
    print('populating complete')
